
import React from 'react'

const Footer = () => {
  return (
    <div className='w-full h-96 bg-slate-900 ' >Footer</div>
  )
}

export default Footer